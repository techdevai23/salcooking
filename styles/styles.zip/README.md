# README - Carpeta styles

Contiene las hojas de estilo CSS, tanto globales como específicas por componente.